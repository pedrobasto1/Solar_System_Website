// script.js for secondary pages
document.getElementById("voltarButton").addEventListener("click", function() {
    window.location.href = "index.html";
});
